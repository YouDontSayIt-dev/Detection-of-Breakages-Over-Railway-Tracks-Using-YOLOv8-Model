# Railway Crack Detection > 2023-10-04 11:42am
https://universe.roboflow.com/thesis-group/railway-crack-detection

Provided by a Roboflow user
License: CC BY 4.0

**INTRODUCTION**
Railway transportation has been a vital mode of transport for many years, primarily chosen for its cost-effectiveness and safety.

**METHODOLOGY**
To develop a real time multi-scaled detection model over railway tracks using YOLOv8